package racing.logic;

/**
 * @deprecated use for testing purposes
 */
public class PlayerSimulation {

	public PlayerSimulation(){

	}

	public void finalize() throws Throwable {

	}

	public static void simulateKeyPress(){

	}

}