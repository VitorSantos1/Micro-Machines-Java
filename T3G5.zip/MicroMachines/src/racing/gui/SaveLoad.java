package racing.gui;
import racing.logic.RacingLogic;

/**
 * @author Owner
 * @version 1.0
 * @created 16-Mai-2011 10:42:31
 */
public class SaveLoad {

	public RacingLogic m_RacingLogic;

	public SaveLoad(){

	}

	public void finalize() throws Throwable {

	}

}