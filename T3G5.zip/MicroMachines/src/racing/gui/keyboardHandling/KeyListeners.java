package racing.gui.keyboardHandling;

public class KeyListeners {

	// Tem em conta a configuracao actual do jogo
}
