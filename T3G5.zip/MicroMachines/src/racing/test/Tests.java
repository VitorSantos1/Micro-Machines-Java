package racing.test;
import org.junit.Test;

import racing.logic.RacingLogic;

public class Tests {

	public RacingLogic m_RacingLogic;

	public Tests(){

	}

	public void finalize() throws Throwable {

	}

	@Test
	public void crashBetweenCars(){

	}

	@Test
	public void crashOnAir(){

	}

	@Test
	public void crashOnLand(){

	}

}