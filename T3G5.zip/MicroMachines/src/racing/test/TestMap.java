package racing.test;

import org.junit.Test;

public class TestMap {

	public TestMap(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * Car has reached an edge of the map; screen only moves in Y.
	 */
	@Test
	public void lockScreenX(){

	}

	/**
	 * Car has reached an edge of the map; screen only moves in X.
	 */
	@Test
	public void lockScreenY(){

	}

	/**
	 * Car moves and the map / screen must follow.
	 */
	@Test
	public void moveScreen_Car(){

	}

	/**
	 * In the editor there is the need to move around the map
	 */
	@Test
	public void moveScreen_Input(){

	}

}