package racing.logic;

public final class keyNotation {

	public static final int ACCELERATE   	  = 0;
	public static final int DECELERATE  	  = 1;
	public static final int LEFT  	          = 2;
	public static final int RIGHT         	  = 3;
	public static final int HANDBRAKE         = 4;
	}
