package racing.logic;

/**
 * @deprecated since the finishline is considered to be the first checkpoint.
 */
public class FinishLine extends Line {

	public FinishLine(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}


}