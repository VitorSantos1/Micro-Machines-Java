package racing.logic;

/**
 * Class that represents a computer controlled player.
 * @deprecated since we didn't implement AI-Logic
 */
public class CPUPlayer extends Player {

	public CPUPlayer(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

}